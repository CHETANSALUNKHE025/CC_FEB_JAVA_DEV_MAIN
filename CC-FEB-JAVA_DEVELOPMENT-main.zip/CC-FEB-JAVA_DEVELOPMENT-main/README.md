# CC-FEB-JAVA DEVELOPMENT

# CODECLAUSE INTERNSHIP
Here I have done total 2 projects : Allocated Project 1 - PDF Splitter and Allocated Project 2 - Text Editor

# Allocated Project 1 : PDF Splitter
The task was to split a single PDF file of multiple pages into multiple files using Java

# Allocated Project 2 : Text Editor
The task was to design a Text Editor using Java
